"""Rebuild every independent fixture and rerun actual GAP/QPA verification.
Usage: GAP_BIN=/path/to/gap python3 run_oracles.py
GAP_BIN may point to the project's scripts/gap.sh wrapper.
"""
import json
import os
from pathlib import Path
import subprocess
from general_brauer import CASES, calculate, gap_oracle

BASE = Path(__file__).parent
GAP = os.environ.get('GAP_BIN', 'gap')
summary = []
for name, spec in CASES.items():
    result = calculate(spec)
    (BASE / (name+'.json')).write_text(json.dumps(result, indent=2)+'\n')
    gapfile = BASE / (name+'.g')
    gap_oracle(spec, result, gapfile)
    logfile = BASE / (name+'.qpa.log')
    with logfile.open('w') as output:
        run = subprocess.run([GAP, '-q', '-b', '--quitonbreak', str(gapfile)],
                             stdout=output, stderr=subprocess.STDOUT)
    text = logfile.read_text()
    assert run.returncode == 0 and 'GENERAL_BRAUER_QPA_PASS' in text, (name, text)
    marker = text.splitlines()[-1]
    summary.append(dict(case=name, algebraDimension=result['algebraDimension'],
                        modules=len(result['modules']), arrows=result['arrowCount'],
                        certificate=result['certificate'], qpa=marker, status='passed'))
    print(name, marker, flush=True)
(BASE / 'oracle-results.json').write_text(json.dumps(summary, indent=2)+'\n')
