"""Compare JS matrices to independent Gaussian oracle by ACTUAL isomorphisms.
Run Python/QPA case generation first; this verifier also compares JS tau with
QPA DTr identified by unique module isomorphisms, never by dimension vectors.
"""
import itertools
import json
import os
import re
import subprocess
from pathlib import Path
from general_brauer import CASES, presentation, hom_basis, combination, rref, module_from_edges

BASE = Path(__file__).parent
NODE = os.environ.get('NODE_BIN', 'node')


def isomorphic(a, source, target):
    if source['dimension'] != target['dimension']:
        return False
    basis = hom_basis(a, source, target)
    if not basis:
        return False
    assert len(basis) <= 5, 'exhaustive isomorphism test limited to Hom dimension 5'
    for c in itertools.product(range(5), repeat=len(basis)):
        if not any(c):
            continue
        f = combination(basis, c)
        if all(len(rref(block)[0]) == len(block) for block in f):
            return True
    return False


results = []
for name, spec in CASES.items():
    py = json.loads((BASE / (name+'.json')).read_text())
    script = 'const B=require(%s); console.log(JSON.stringify(B.build(%s)));' % (
        json.dumps(str((BASE / 'brauer-tree.js').resolve())), json.dumps(spec))
    run = subprocess.run([NODE, '-e', script], text=True, capture_output=True, check=True)
    js = json.loads(run.stdout)
    (BASE / (name+'.js.json')).write_text(json.dumps(js, indent=2)+'\n')
    a = presentation(spec)
    arrow_map = []
    for arrow in js['quiver']['arrows']:
        candidates = [i for i, aa in enumerate(a['arrows'])
                      if aa['source'] == arrow['source'] and aa['target'] == arrow['target']
                      and str(aa['vertex']) == str(arrow['treeVertex'])]
        assert len(candidates) == 1
        arrow_map.append(candidates[0])
    jsmodules = []
    for node in js['nodes']:
        actions = [(arrow_map[k], s, t) for k, pairs in enumerate(node['arrowMaps']) for s, t in pairs]
        jsmodules.append(module_from_edges(a, node['id'], node['basisVertices'], actions,
                                          projective=node['projective']))
    mapping = []
    for pm in py['modules']:
        matches = [i for i, jm in enumerate(jsmodules) if isomorphic(a, pm, jm)]
        assert len(matches) == 1, (name, pm['label'], matches)
        mapping.append(matches[0])
    assert len(mapping) == len(js['nodes']) and len(set(mapping)) == len(mapping)
    ids = {node['id']: i for i, node in enumerate(js['nodes'])}
    jsirr = [[0]*len(ids) for _ in ids]
    for edge in js['edges']:
        jsirr[ids[edge['source']]][ids[edge['target']]] += edge['multiplicity']
    for i, ii in enumerate(mapping):
        for j, jj in enumerate(mapping):
            assert py['hom'][i][j] == js['homMatrix'][ii][jj], (name, 'Hom', i, j)
            assert py['irreducibles'][i][j] == jsirr[ii][jj], (name, 'Irr', i, j)
    log = (BASE / (name+'.qpa.log')).read_text()
    assert 'GENERAL_BRAUER_QPA_PASS' in log
    tau = json.loads(re.search(r'^TAU_INDICES=(.*)$', log, re.M).group(1))
    for i, ii in enumerate(mapping):
        actual = js['nodes'][ii]['tauId']
        expected = None if tau[i] == 0 else js['nodes'][mapping[tau[i]-1]]['id']
        assert actual == expected, (name, 'DTr', i, actual, expected)
    entry = dict(case=name, modules=len(mapping), arrows=sum(map(sum, jsirr)),
                 allHomPairs=len(mapping)**2, matrixIsomorphisms=True,
                 actualQpaDTr=True, status='passed')
    results.append(entry)
    print('JS_PYTHON_QPA_CROSSCHECK_PASS', json.dumps(entry), flush=True)
(BASE / 'crosscheck-results.json').write_text(json.dumps(results, indent=2)+'\n')
