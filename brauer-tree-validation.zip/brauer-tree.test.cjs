'use strict';
const assert = require('node:assert/strict');
const B = require('./brauer-tree.js');

function star(n, m) {
  return B.build({edges: Array.from({length: n}, (_, i) => ['center', 'leaf' + i]), exceptionalVertex: 'center', multiplicity: m});
}

// Independent cyclic-Nakayama Hom formula, including repeated dimension vectors.
for (const [n, m] of [[1, 1], [1, 3], [2, 3], [3, 1], [3, 2]]) {
  const data = star(n, m), L = n * m + 1;
  assert.equal(data.nodes.length, n * L);
  assert.equal(data.edges.length, 2 * n * (L - 1));
  const index = new Map(data.nodes.map((x, i) => [x.id, i]));
  for (const source of data.nodes) {
    const i = source.top.indexOf(1), l = source.compositionLength;
    assert.equal(source.top.reduce((a, b) => a + b), 1);
    assert.equal(source.endDimension, Math.floor((l - 1) / n) + 1);
    if (l < L) {
      const translated = data.nodes[index.get(source.tauId)];
      assert.equal(translated.top.indexOf(1), (i + 1) % n);
      assert.equal(translated.compositionLength, l);
    } else assert.equal(source.tauId, null);
    for (const target of data.nodes) {
      const j = target.top.indexOf(1), t = target.compositionLength;
      let expected = 0;
      for (let r = Math.max(0, t - l); r < t; r++) if ((j + r) % n === i) expected++;
      assert.equal(data.homMatrix[index.get(source.id)][index.get(target.id)], expected);
    }
  }
}

// Hand-derived three-edge line fixture. It has the same counts as the star,
// but a different algebra dimension, biserial projectives, and attachments.
const line = B.build({edges: [['0', '1'], ['1', '2'], ['2', '3']], multiplicity: 1});
assert.equal(line.algebraDimension, 10);
function name(node) {
  if (node.projective) return node.label;
  const d = node.dimension.join('');
  if (d === '100') return 'S1';
  if (d === '010') return 'S2';
  if (d === '001') return 'S3';
  if (d === '110') return node.top[0] ? 'U12' : 'U21';
  if (d === '011') return node.top[1] ? 'U23' : 'U32';
  if (d === '111') return node.top[1] ? 'V' : 'W';
  throw new Error('unexpected line module');
}
const names = new Map(line.nodes.map(node => [node.id, name(node)]));
const actualEdges = line.edges.map(edge => names.get(edge.source) + '>' + names.get(edge.target)).sort();
const expectedEdges = ['S1>V', 'S2>U12', 'S2>U32', 'S3>V', 'U12>W', 'U21>S2', 'U21>P1', 'U23>S2', 'U23>P3', 'U32>W', 'V>U21', 'V>U23', 'W>S1', 'W>S3', 'W>P2', 'P1>U12', 'P2>V', 'P3>U32'].sort();
assert.deepEqual(actualEdges, expectedEdges);
const expectedTau = {S1: 'U32', U32: 'U23', U23: 'S1', S3: 'U12', U12: 'U21', U21: 'S3', S2: 'V', V: 'W', W: 'S2'};
for (const node of line.nodes) if (!node.projective) assert.equal(names.get(node.tauId), expectedTau[name(node)]);

// A nonstandard cyclic order must actually determine the successor arrows.
const reordered = B.build({edges: [['0', '1'], ['0', '2'], ['0', '3']], orders: {'0': [0, 2, 1]}, exceptionalVertex: '0', multiplicity: 2});
assert.deepEqual(reordered.quiver.edges, [[0, 2], [2, 1], [1, 0]]);
assert.equal(reordered.nodes.length, 21);

// Labels are arbitrary strings; prototype-like labels must not affect parsing.
const unusualLabels = B.build({edges: [['__proto__', 'constructor'], ['constructor', 'toString']], exceptionalVertex: '__proto__', multiplicity: 2});
assert.equal(unusualLabels.nodes.length, 10);
assert.doesNotThrow(() => structuredClone(unusualLabels));
assert.doesNotThrow(() => JSON.stringify(unusualLabels));
assert.throws(() => B.build({edges: [['0', '1'], ['1', '2'], ['2', '0']]}), /树/);
assert.throws(() => B.build({edges: [['0', '1'], ['0', '2']], orders: {'0': [0, 0]}}), /循环序/);
assert.throws(() => B.build({edges: [['0', '1']], orders: {'0': '0'}}), /数组/);
assert.throws(() => B.build({edges: Array.from({length: 10}, (_, i) => ['0', '' + (i + 1)]), multiplicity: 2}), /150/);
console.log('BRAUER_TREE_JS_TESTS_PASS: cyclic Hom benchmarks; independent line AR/tau fixture; cyclic order; single-edge cases; labels; invalid input; resource bound.');
