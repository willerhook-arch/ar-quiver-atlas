"""Independent exact GF(5) oracle for finite Brauer TREE algebras.

Source for quiver/relations and finite-type hypotheses:
S. Schroll, Brauer graph algebras, arXiv:1612.00061, §§2.2–2.6.
Nonprojectives are the strings of A/soc(A); no bands occur for a tree with
at most one exceptional vertex. Enumeration proves the accepted string
language finite by checking its prefix automaton is a DAG, then exhausts it.
All matrices use RIGHT modules (row vectors), with integer entries modulo 5.
This implementation deliberately uses Gaussian nullspaces, independently of
brauer-tree.js's partial-permutation/union-find Hom solver.
"""
import argparse
import collections
import itertools
import json
from pathlib import Path

P = 5


def rref(rows, width=None):
    if width is None:
        width = len(rows[0]) if rows else 0
    a = [[x % P for x in row] for row in rows if any(x % P for x in row)]
    pivots = []
    for col in range(width):
        r = next((i for i in range(len(pivots), len(a)) if a[i][col]), None)
        if r is None:
            continue
        k = len(pivots)
        a[k], a[r] = a[r], a[k]
        inv = pow(a[k][col], P-2, P)
        a[k] = [x*inv % P for x in a[k]]
        for i in range(len(a)):
            if i != k and a[i][col]:
                c = a[i][col]
                a[i] = [(x-c*y) % P for x, y in zip(a[i], a[k])]
        pivots.append(col)
    return a[:len(pivots)], pivots


def nullspace(rows, width):
    reduced, pivots = rref(rows, width)
    result = []
    for free in range(width):
        if free in pivots:
            continue
        v = [0]*width
        v[free] = 1
        for row, col in zip(reduced, pivots):
            v[col] = -row[free] % P
        result.append(v)
    return result


def matmul(a, b, columns=None):
    if columns is None:
        columns = len(b[0]) if b else 0
    return [[sum(a[i][k]*b[k][j] for k in range(len(b))) % P
             for j in range(columns)] for i in range(len(a))]


def flatten(blocks):
    return [x for block in blocks for row in block for x in row]


def inverse(word):
    return tuple(-x for x in reversed(word))


def presentation(spec):
    edges = [tuple(e) for e in spec['edges']]
    vertices = sorted(set(v for e in edges for v in e))
    assert edges and all(len(e) == 2 and e[0] != e[1] for e in edges)
    assert len(vertices) == len(edges)+1
    incident = {v: [i for i, e in enumerate(edges) if v in e] for v in vertices}
    seen = {vertices[0]}
    while True:
        bigger = seen | {v for e in edges if any(w in seen for w in e) for v in e}
        if bigger == seen:
            break
        seen = bigger
    assert len(seen) == len(vertices), 'input must be a connected tree'
    orders = {v: list(spec.get('orders', {}).get(str(v), spec.get('orders', {}).get(v, incident[v]))) for v in vertices}
    assert all(sorted(orders[v]) == incident[v] for v in vertices)
    mult = {v: spec.get('multiplicity', 1) if v == spec.get('exceptionalVertex') else 1 for v in vertices}
    assert all(isinstance(m, int) and m >= 1 for m in mult.values())
    arrows, cycles = [], {}
    if len(edges) == 1 and max(mult.values()) == 1:
        arrows = [{'source': 0, 'target': 0, 'vertex': vertices[0], 'name': 'a0'}]
        zero, binomial, cut = [(1, 1)], [], [(1,)]
    else:
        for v in vertices:
            order = orders[v]
            if len(order)*mult[v] == 1:
                continue
            ids = []
            for i, e in enumerate(order):
                ids.append(len(arrows)+1)
                arrows.append({'source': e, 'target': order[(i+1) % len(order)], 'vertex': v, 'name': 'a'+str(len(arrows))})
            for i, e in enumerate(order):
                cycles[v, e] = tuple(ids[i:]+ids[:i])
        cut = [cycle*mult[v] for (v, e), cycle in cycles.items()]
        zero = [word+(word[0],) for word in cut]
        binomial = []
        for e, (u, v) in enumerate(edges):
            if (u, e) in cycles and (v, e) in cycles:
                binomial.append((cycles[u, e]*mult[u], cycles[v, e]*mult[v]))
        for i, a in enumerate(arrows):
            for j, b in enumerate(arrows):
                if a['target'] == b['source'] and a['vertex'] != b['vertex']:
                    zero.append((i+1, j+1))
        cut += [w for w in zero if len(w) == 2]
    return dict(edges=edges, vertices=vertices, orders=orders, multiplicities=mult,
                arrows=arrows, cycles=cycles, zero=zero, binomial=binomial, cut=cut,
                dimension=sum(mult[v]*len(incident[v])**2 for v in vertices))


def enumerate_strings(a):
    forbidden = set(a['cut'])
    forbidden |= {inverse(w) for w in forbidden}
    for i in range(1, len(a['arrows'])+1):
        forbidden.add((i, -i))
        forbidden.add((-i, i))
    prefixes = {()}
    for w in forbidden:
        prefixes.update(w[:i] for i in range(1, len(w)))
    outgoing = collections.defaultdict(list)
    for i, arrow in enumerate(a['arrows'], 1):
        outgoing[arrow['source']].append((i, arrow['target']))
        outgoing[arrow['target']].append((-i, arrow['source']))
    roots = [(v, ()) for v in range(len(a['edges']))]
    graph = {}
    queue = collections.deque(roots)
    while queue:
        state = queue.popleft()
        if state in graph:
            continue
        v, suffix = state
        nexts = []
        for letter, end in outgoing[v]:
            extended = suffix+(letter,)
            if any(len(w) <= len(extended) and extended[-len(w):] == w for w in forbidden):
                continue
            candidates = [w for w in prefixes if not w or extended[-len(w):] == w]
            nextstate = (end, max(candidates, key=len))
            nexts.append((letter, nextstate))
            queue.append(nextstate)
        graph[state] = nexts
    colours, longest = {}, {}
    def check_dag(s):
        if colours.get(s) == 1:
            raise ValueError('infinite accepted string language; finite AR cannot be claimed')
        if colours.get(s) == 2:
            return longest[s]
        colours[s] = 1
        longest[s] = max((1+check_dag(t) for _, t in graph[s]), default=0)
        colours[s] = 2
        return longest[s]
    for root in roots:
        check_dag(root)
    canonical = set()
    def walk(start, s, word):
        canonical.add(min((start, word), (s[0], inverse(word))))
        for letter, t in graph[s]:
            walk(start, t, word+(letter,))
    for root in roots:
        walk(root[0], root, ())
    return sorted(canonical, key=lambda x: (len(x[1]), x)), {
        'states': len(graph), 'acyclic': True,
        'maximumStringLength': max(longest[r] for r in roots),
        'stringCount': len(canonical), 'enumerationExhausted': True}


def module_from_edges(a, label, basis_vertices, action_edges, **meta):
    n = len(a['edges'])
    dims, local = [0]*n, []
    for v in basis_vertices:
        local.append(dims[v])
        dims[v] += 1
    matrices = [[[0]*dims[arrow['target']] for _ in range(dims[arrow['source']])] for arrow in a['arrows']]
    for arrow, source, target in action_edges:
        matrices[arrow][local[source]][local[target]] += 1
    return dict(label=label, dimension=dims, matrices=matrices, **meta)


def string_module(a, start, word):
    vertices, actions = [start], []
    for k, letter in enumerate(word):
        arrow = a['arrows'][abs(letter)-1]
        if letter > 0:
            assert vertices[-1] == arrow['source']
            vertices.append(arrow['target'])
            actions.append((letter-1, k, k+1))
        else:
            assert vertices[-1] == arrow['target']
            vertices.append(arrow['source'])
            actions.append((-letter-1, k+1, k))
    return module_from_edges(a, 'S%d:%s' % (start, ','.join(map(str, word))), vertices, actions,
                             word=list(word), start=start, projective=False)


def projective_module(a, edge):
    vertices, actions = [edge, edge], []
    if len(a['edges']) == 1 and not a['cycles']:
        actions.append((0, 0, 1))
    else:
        for v in a['edges'][edge]:
            cycle = a['cycles'].get((v, edge))
            if cycle is None:
                continue
            word = cycle*a['multiplicities'][v]
            previous = 0
            for k, letter in enumerate(word):
                if k == len(word)-1:
                    current = 1
                else:
                    current = len(vertices)
                    vertices.append(a['arrows'][letter-1]['target'])
                actions.append((letter-1, previous, current))
                previous = current
    return module_from_edges(a, 'P%d' % edge, vertices, actions, top=edge, projective=True)


def hom_basis(a, source, target):
    s, t = source['dimension'], target['dimension']
    offsets, width = [], 0
    for d, e in zip(s, t):
        offsets.append(width)
        width += d*e
    rows = []
    for k, arrow in enumerate(a['arrows']):
        u, v = arrow['source'], arrow['target']
        ma, na = source['matrices'][k], target['matrices'][k]
        for i in range(s[u]):
            for j in range(t[v]):
                eq = [0]*width
                for h in range(s[v]):
                    eq[offsets[v]+h*t[v]+j] += ma[i][h]
                for h in range(t[u]):
                    eq[offsets[u]+i*t[u]+h] -= na[h][j]
                rows.append(eq)
    result = []
    for vector in nullspace(rows, width):
        result.append([[[vector[offsets[v]+i*t[v]+j] for j in range(t[v])]
                        for i in range(s[v])] for v in range(len(s))])
    return result


def compose(f, g, target):
    return [matmul(a, b, d) for a, b, d in zip(f, g, target['dimension'])]


def combination(basis, coefficients):
    if not basis:
        return []
    return [[[sum(c*b[v][i][j] for c, b in zip(coefficients, basis)) % P
              for j in range(len(row))] for i, row in enumerate(block)]
            for v, block in enumerate(basis[0])]


def radical_basis(module, end_basis, exhaustive=True):
    vertex = next(i for i, d in enumerate(module['dimension']) if d)
    diagonal = [b[vertex][0][0] for b in end_basis]
    coefficients = nullspace([diagonal], len(end_basis))
    radical = [combination(end_basis, c) for c in coefficients]
    # For these canonical tree/string bases every endomorphism has constant
    # diagonal. Verify that condition, then independently enumerate ALL end
    # elements to check that precisely the diagonal-zero elements are nonunits.
    for b in end_basis:
        assert all(b[v][i][i] == b[vertex][0][0]
                   for v, d in enumerate(module['dimension']) for i in range(d))
    assert len(radical) == len(end_basis)-1
    if exhaustive:
        if len(end_basis) > 5:
            raise ValueError('exhaustive End nonunit oracle limited to dimension 5')
        for c in itertools.product(range(P), repeat=len(end_basis)):
            f = combination(end_basis, c)
            invertible = all(len(rref(block)[0]) == len(block) for block in f)
            scalar = sum(x*y for x, y in zip(c, diagonal)) % P
            assert invertible == bool(scalar), (module['label'], c, 'local End check failed')
    return radical


def calculate(spec, ar=True, exhaustive_end=True):
    a = presentation(spec)
    strings, certificate = enumerate_strings(a)
    modules = [string_module(a, start, word) for start, word in strings]
    modules += [projective_module(a, e) for e in range(len(a['edges']))]
    assert sum(sum(m['dimension']) for m in modules if m['projective']) == a['dimension']
    hom = [[hom_basis(a, source, target) for target in modules] for source in modules]
    radical = [[basis for basis in row] for row in hom]
    for i, module in enumerate(modules):
        radical[i][i] = radical_basis(module, hom[i][i], exhaustive_end)
    irr = [[0]*len(modules) for _ in modules]
    if ar:
        for i, source in enumerate(modules):
            for j, target in enumerate(modules):
                compositions = [flatten(compose(f, g, target))
                                for k in range(len(modules))
                                for f in radical[i][k] for g in radical[k][j]]
                radical_rows = [flatten(f) for f in radical[i][j]]
                rank = len(rref(compositions)[0])
                assert len(rref(radical_rows+compositions)[0]) == len(radical_rows)
                irr[i][j] = len(radical_rows)-rank
    return dict(input=spec, algebraDimension=a['dimension'], arrows=a['arrows'],
                modules=modules, certificate=certificate,
                hom=[[len(b) for b in row] for row in hom],
                endRadicalDimensions=[len(radical[i][i]) for i in range(len(modules))],
                irreducibles=irr, arrowCount=sum(map(sum, irr)))


def gap_oracle(spec, result, path):
    a = presentation(spec)
    def literal(value):
        return json.dumps(value, separators=(',', ':'))
    def gap_path(word):
        return '*'.join('K.a%d' % (x-1) for x in word)
    relations = [gap_path(w) for w in a['zero']]
    relations += [gap_path(u)+'-'+gap_path(v) for u, v in a['binomial']]
    arrows = [[x['source']+1, x['target']+1, x['name']] for x in a['arrows']]
    lines = [
        'LoadPackage("qpa",false);; SizeScreen([1000000,1000000]);;',
        'checks:=0;; Check:=function(c,s) if not c then Print("FAIL: ",s,"\\n"); FORCE_QUIT_GAP(1); fi; checks:=checks+1; end;;',
        'F:=GF(5);; Q:=Quiver(%d,%s);; K:=PathAlgebra(F,Q);;' % (len(a['edges']), literal(arrows)),
        'rels:=['+','.join(relations)+'];; gb:=GBNPGroebnerBasis(rels,K);; I:=Ideal(K,gb);; GroebnerBasis(I,gb);; A:=K/I;;',
        'Check(Dimension(A)=%d,"algebra dimension");;' % result['algebraDimension'],
        'mods:=[];;']
    for module in result['modules']:
        actions = [[arrow['name'], matrix] for arrow, matrix in zip(a['arrows'], module['matrices'])
                   if module['dimension'][arrow['source']] and module['dimension'][arrow['target']]]
        lines += ['Add(mods,RightModuleOverPathAlgebra(A,%s,List(%s,x->[x[1],x[2]*One(F)])));;' % (literal(module['dimension']), literal(actions))]
    lines += [
        'N:=Length(mods);; inds:=[1..N];; H:=List(mods,M->List(mods,N->HomOverAlgebra(M,N)));;',
        'expectedHom:=%s;;' % literal(result['hom']),
        'Check(List(H,row->List(row,Length))=expectedHom,"all Hom dimensions");;',
        'expectedProjective:=%s;;' % literal([m['projective'] for m in result['modules']]).replace('true','true').replace('false','false'),
        'R:=List(H,ShallowCopy);; endrads:=[];;',
        'for i in inds do',
        'Check(IsIndecomposableModule(mods[i]),"indecomposable");',
        'Check(IsProjectiveModule(mods[i])=expectedProjective[i],"projective criterion");',
        'Check(IsInjectiveModule(mods[i])=expectedProjective[i],"injective criterion");',
        'endAlg:=EndOverAlgebra(mods[i]); J:=RadicalOfAlgebra(endAlg); Add(endrads,Dimension(J));',
        'Check(Dimension(endAlg)-Dimension(J)=1,"split local End");',
        'R[i][i]:=List(BasisVectors(Basis(J)),x->FromEndMToHomMM(mods[i],x));',
        'for j in [i+1..N] do Check(IsomorphismOfModules(mods[i],mods[j])=false,"pairwise nonisomorphic"); od;',
        'od;',
        'Check(endrads=%s,"all End radical dimensions");;' % literal(result['endRadicalDimensions']),
        'FlattenHom:=f->Flat(MatricesOfPathAlgebraMatModuleHomomorphism(f));;',
        'SafeRank:=function(rows) if IsEmpty(rows) then return 0; fi; return RankMat(rows); end;;',
        'irr:=List(inds,i->List(inds,j->0));;',
        'for i in inds do for j in inds do rows:=[]; for k in inds do for f in R[i][k] do for g in R[k][j] do Add(rows,FlattenHom(f*g)); od; od; od;',
        'irr[i][j]:=Length(R[i][j])-SafeRank(rows); od; od;',
        'Check(irr=%s,"all irreducible multiplicities via actual rad/rad^2");;' % literal(result['irreducibles']),
        'Match:=function(M) return Filtered(inds,j->IsomorphismOfModules(M,mods[j])<>false); end;;',
        'tau:=[];; for i in inds do T:=DTr(mods[i]); if expectedProjective[i] then Check(IsZero(T),"DTr projective zero"); Add(tau,0); else matches:=Match(T); Check(Length(matches)=1,"unique DTr isomorphism"); Add(tau,matches[1]); fi; od;',
        'Print("ALGEBRA_DIMENSION=",Dimension(A),"\\nHOM_MATRIX=",List(H,row->List(row,Length)),"\\nIRREDUCIBLE_MULTIPLICITIES=",irr,"\\nTAU_INDICES=",tau,"\\n");',
        'Print("GENERAL_BRAUER_QPA_PASS modules=",N," arrows=",Sum(irr,Sum)," checks=",checks,"\\n"); QUIT_GAP(0);'
    ]
    Path(path).write_text('\n'.join(lines)+'\n')


CASES = {
    'edge1_m1': {'edges': [[0, 1]]},
    'edge1_m2': {'edges': [[0, 1]], 'exceptionalVertex': 0, 'multiplicity': 2},
    'line3_m1': {'edges': [[0, 1], [1, 2], [2, 3]]},
    'line3_internal_m2': {'edges': [[0, 1], [1, 2], [2, 3]], 'exceptionalVertex': 1, 'multiplicity': 2},
    'line3_leaf_m2': {'edges': [[0, 1], [1, 2], [2, 3]], 'exceptionalVertex': 0, 'multiplicity': 2},
    'fork4_m1': {'edges': [[0, 1], [1, 2], [1, 3], [3, 4]], 'orders': {'1': [0, 2, 1]}},
    'fork4_m2': {'edges': [[0, 1], [1, 2], [1, 3], [3, 4]], 'orders': {'1': [0, 2, 1]}, 'exceptionalVertex': 3, 'multiplicity': 2},
    'doublefork5_m1': {'edges': [[0, 1], [1, 2], [1, 3], [3, 4], [3, 5]], 'orders': {'1': [0, 2, 1], '3': [2, 4, 3]}},
    'doublefork5_m2': {'edges': [[0, 1], [1, 2], [1, 3], [3, 4], [3, 5]], 'orders': {'1': [0, 2, 1], '3': [2, 4, 3]}, 'exceptionalVertex': 3, 'multiplicity': 2},
}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('cases', nargs='*', choices=list(CASES))
    parser.add_argument('--output', default=str(Path(__file__).parent))
    args = parser.parse_args()
    for name in args.cases or CASES:
        result = calculate(CASES[name])
        Path(args.output, name+'.json').write_text(json.dumps(result, indent=2)+'\n')
        gap_oracle(CASES[name], result, Path(args.output, name+'.g'))
        print(name, 'dimension=', result['algebraDimension'], 'modules=', len(result['modules']),
              'arrows=', result['arrowCount'], 'certificate=', result['certificate'], flush=True)
