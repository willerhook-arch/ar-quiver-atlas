"""Run independent QPA's native constructor on nondegenerate default-order cases.
QPA 1.37 sorts cyclic orders in place (reported separately); therefore its native
constructor is NOT a reference for arbitrary supplied ribbon embeddings.
"""
import json
import os
import subprocess
from pathlib import Path
from general_brauer import CASES, presentation

BASE = Path(__file__).parent
GAP = os.environ.get('GAP_BIN', 'gap')

for name in ['line3_m1', 'line3_internal_m2', 'line3_leaf_m2']:
    spec = CASES[name]
    a = presentation(spec)
    config = [[[f'v{v}', a['multiplicities'][v]] for v in a['vertices']],
              [[f'e{i}', f'v{u}', f'v{v}'] for i, (u, v) in enumerate(a['edges'])],
              [[f'e{e}' for e in a['orders'][v]] for v in a['vertices']]]
    lines = (BASE / (name+'.g')).read_text().splitlines()
    lines[2] = 'F:=GF(5);;'
    lines[3] = 'A:=BrauerConfigurationAlgebra(F,%s);;' % json.dumps(config)
    text = '\n'.join(lines)+'\n'
    for arrow in a['arrows']:
        v = arrow['vertex']
        index = a['orders'][v].index(arrow['source'])+1
        label = f'v{v}_{index}_from_e{arrow["source"]}_to_e{arrow["target"]}'
        text = text.replace('"'+arrow['name']+'"', '"'+label+'"')
    text = text.replace('GENERAL_BRAUER_QPA_PASS', 'NATIVE_BRAUER_QPA_PASS')
    path = BASE / (name+'.native.g')
    path.write_text(text)
    log = BASE / (name+'.native.qpa.log')
    with log.open('w') as output:
        result = subprocess.run([str(GAP), '-q', '-b', '--quitonbreak', str(path)],
                                stdout=output, stderr=subprocess.STDOUT)
    print(name, 'native exit=', result.returncode, log.read_text().splitlines()[-1], flush=True)
    assert result.returncode == 0
