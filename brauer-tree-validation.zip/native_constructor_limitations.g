# Diagnostic for QPA 1.37's native constructor; these known limitations are
# why the atlas retains its explicit bound-quiver construction.
LoadPackage("qpa",false);;
SizeScreen([1000000,1000000]);;
config := [ [["v0",1],["v1",1],["v2",1],["v3",1],["v4",1]],
 [["e0","v0","v1"],["e1","v1","v2"],["e2","v1","v3"],["e3","v3","v4"]],
 [["e0"],["e0","e2","e1"],["e1"],["e2","e3"],["e3"]] ];;
Print("QPA_VERSION=",PackageInfo("qpa")[1].Version,"\n");
Print("CYCLIC_ORDER_BEFORE=",config[3][2],"\n");
native := BrauerConfigurationAlgebra(GF(5),config);;
Print("CYCLIC_ORDER_AFTER=",config[3][2],"\n");
Print("DIAGNOSTIC: the QPA 1.37 native constructor sorts the supplied cyclic orders in place.\n");
edge := BrauerConfigurationAlgebra(GF(5),[[["u",1],["v",1]],[["e","u","v"]],[["e"],["e"]]]);;
Print("SINGLE_EDGE_M1_NATIVE_DIMENSION=",Dimension(edge),"\n");
Print("SINGLE_EDGE_M1_BRAUER_TREE_EXPECTED_DIMENSION=2\n");
QUIT_GAP(0);
