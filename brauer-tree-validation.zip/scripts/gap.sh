#!/usr/bin/env bash
set -euo pipefail
LAB_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$LAB_ROOT/versions.env"
LAB_GAP="$LAB_ROOT/.tools/gap-$GAP_VERSION/gap"
if [[ ! -x "$LAB_GAP" ]]; then
    echo "GAP is not installed in this checkout. Run: bash scripts/bootstrap.sh" >&2
    exit 1
fi
# Ignore user preferences and suggested package autoloads for reproducibility.
exec "$LAB_GAP" -r -A "$@"
