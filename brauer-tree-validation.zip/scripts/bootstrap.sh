#!/usr/bin/env bash
# Install in this checkout without sudo, Homebrew, or system GAP packages.
set -euo pipefail
LAB_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$LAB_ROOT/versions.env"
LAB_TOOLS="$LAB_ROOT/.tools"
LAB_DOWNLOADS="$LAB_TOOLS/downloads"
LAB_GAP="$LAB_TOOLS/gap-$GAP_VERSION"
LAB_LOGS="$LAB_TOOLS/logs"
LAB_ARCHIVE="$LAB_DOWNLOADS/$GAP_ARCHIVE"

case "${1:-}" in
    ""|--download-only) ;;
    *) echo "Usage: bash scripts/bootstrap.sh [--download-only]" >&2; exit 2 ;;
esac
for tool in curl tar python3; do
    command -v "$tool" >/dev/null || { echo "Missing prerequisite: $tool" >&2; exit 1; }
done
mkdir -p "$LAB_DOWNLOADS" "$LAB_LOGS"

archive_hash() {
    python3 - "$1" <<'PY'
import hashlib, sys
digest = hashlib.sha256()
with open(sys.argv[1], "rb") as source:
    for block in iter(lambda: source.read(1024 * 1024), b""):
        digest.update(block)
print(digest.hexdigest())
PY
}

if [[ ! -f "$LAB_ARCHIVE" ]]; then
    echo "Downloading the pinned GAP $GAP_VERSION distribution (~578 MB)."
    curl --fail --location --show-error --retry 3 --connect-timeout 30 \
        --output "$LAB_ARCHIVE.part" "$GAP_ARCHIVE_URL"
    mv "$LAB_ARCHIVE.part" "$LAB_ARCHIVE"
fi
echo "Checking SHA-256 of $GAP_ARCHIVE."
if [[ "$(archive_hash "$LAB_ARCHIVE")" != "$GAP_ARCHIVE_SHA256" ]]; then
    echo "SHA-256 mismatch; refusing to extract or execute the download." >&2
    echo "Inspect or remove $LAB_ARCHIVE, then retry." >&2
    exit 1
fi
if [[ "${1:-}" == --download-only ]]; then
    echo "Verified archive ready: $LAB_ARCHIVE"
    exit 0
fi

for tool in make "${CC:-cc}"; do
    command -v "$tool" >/dev/null || { echo "Missing prerequisite: $tool" >&2; exit 1; }
done
LAB_JOBS="${JOBS:-4}"
if [[ ! "$LAB_JOBS" =~ ^[1-9][0-9]*$ ]]; then
    echo "JOBS must be a positive integer." >&2
    exit 2
fi

# Keep a build marker tied to this operating system and architecture.
LAB_BUILD_ID="$GAP_ARCHIVE_SHA256 $(uname -sm)"
if [[ -f "$LAB_GAP/.lab-extracted" ]] && \
   [[ "$(cat "$LAB_GAP/.lab-extracted")" != "$GAP_ARCHIVE_SHA256" ]]; then
    echo "The extracted source belongs to a different archive checksum." >&2
    echo "Move $LAB_GAP aside for a fresh installation, then retry." >&2
    exit 1
fi
if [[ ! -f "$LAB_GAP/.lab-build-complete" ]] || \
   [[ "$(cat "$LAB_GAP/.lab-build-complete" 2>/dev/null)" != "$LAB_BUILD_ID" ]]; then
    if [[ ! -f "$LAB_GAP/.lab-extracted" ]]; then
        echo "Extracting GAP and the packages bundled with the pinned release."
        mkdir -p "$LAB_GAP"
        tar -xzf "$LAB_ARCHIVE" -C "$LAB_GAP" --strip-components=1
        printf '%s\n' "$GAP_ARCHIVE_SHA256" >"$LAB_GAP/.lab-extracted"
    fi
    echo "Building GAP with bundled GMP; logs: $LAB_LOGS"
    # Release flags avoid unnecessary debug-symbol generation (dsymutil on macOS).
    if ! (cd "$LAB_GAP" && ./configure --with-gmp=builtin --without-readline \
        CFLAGS="${CFLAGS:--O2}" CXXFLAGS="${CXXFLAGS:--O2}") \
        >"$LAB_LOGS/configure.log" 2>&1; then
        tail -60 "$LAB_LOGS/configure.log" >&2
        exit 1
    fi
    if ! (cd "$LAB_GAP" && make -j"$LAB_JOBS") >"$LAB_LOGS/build.log" 2>&1; then
        tail -60 "$LAB_LOGS/build.log" >&2
        exit 1
    fi
fi

echo "Checking the actual GAP/QPA versions and loading QPA."
"$LAB_GAP/gap" -r -A -q --quitonbreak -c \
    "if GAPInfo.Version <> \"$GAP_VERSION\" then Error(\"Unexpected GAP version\"); fi; if LoadPackage(\"qpa\", false) <> true then Error(\"Cannot load QPA\"); fi; if PackageInfo(\"qpa\")[1].Version <> \"$QPA_VERSION\" then Error(\"Unexpected QPA version\"); fi; Print(\"GAP \", GAPInfo.Version, \"; QPA \", PackageInfo(\"qpa\")[1].Version, \"; GBNP \", PackageInfo(\"GBNP\")[1].Version, \"\\n\"); QUIT_GAP(0);" \
    | tee "$LAB_LOGS/versions.log"
printf '%s\n' "$LAB_BUILD_ID" >"$LAB_GAP/.lab-build-complete"
echo "Ready. Use bash scripts/gap.sh or bash scripts/test.sh."
